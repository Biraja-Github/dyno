// Logger
var logger = require('./lib/logger.js').getLogger();
var POSTGRESQL =require('./lib/postgresql.connector.js');
var ENV = process.env;

var util = require('util');
var _ = require('lodash');

//Template libraries
var handlebars = require('handlebars');
var hbs = require('hbs');

//Express libraries
var express = require('express');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var methodOverride = require('method-override');

var json2xls = require('./lib/json2xls');

// Custom route libraries
var dashboards = require('./lib/dashboards.js');
var routes = require('./lib/routes.js');
var sources = require('./lib/sources.js');
var widgets = require('./lib/widgets.js');
var utils = require('./lib/utils.js');
var helpers = require('./lib/helpers.js');
var config = require(__dirname + '/config/config.json');

var DEBUG = (ENV.npm_package_config_debug === 'true');

if (!ENV.npm_package_config_env
    || (ENV.npm_package_config_env === 'REPLACE_ME')) {
    logger.error('Run: npm config -g set mashups:env "YOUR ENVIRONMENT"');
    process.exit(1);
}
else {
    process.env.NODE_ENV = ENV.npm_package_config_env;
}

/*
 Adds support for passing arguments to partials. Arguments are merged with
 the context for rendering only (non destructive). Use `:token` syntax to
 replace parts of the template path. Tokens are replace in order.

 USAGE: {{$ 'path.to.partial' var1=value1 var2='value2' }}
 */
hbs.registerHelper('$', function (partial) {
    var values, proxyData = JSON.parse(this.proxyData), context;

    if (!partial) {
        logger.error('No partial name given.');
    }
    partial = hbs.partials[partial];
    if (!partial) {
        logger.error('Please check the first argument is valid partial name.');
        return '';
    }

    var hash = Array.prototype.slice.call(arguments, 1)[0].hash;
    context = _.assign(proxyData, hash);
    return new hbs.SafeString(partial(context));
});

hbs.registerHelper('filterCounts', helpers.filterCounts);
hbs.registerHelper('optionTag', helpers.optionTag);
hbs.registerHelper('title', helpers.title);
/***** templates helpers reg end*****/

var app = express();

hbs.registerPartials(__dirname + '/views/partials', function () {
    helpers.preCompileHandlebarsPartials(hbs);
});

app.set('application', 'mashups');
app.set('application_icon', 'mashups');
app.set('env_prefix', ENV.npm_package_config_env);

app.set('views', __dirname + '/views');
app.set('view engine', 'hbs');
app.engine('hbs', hbs.__express);

app.use(routes.healthCheck);

app.use(express.static(__dirname + '/public', {'maxAge': 604800000}));

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
// parse application/json
app.use(bodyParser.json());

app.use(cookieParser());
app.use(methodOverride());

app.use(json2xls.middleware);


// Error handling middleware that returns JSON
app.use(function (err, req, res, next) {
    var msg;
    if (err.hasOwnProperty('message')) {
        msg = err.message;
    }
    else {
        msg = util.inspect(err);
    }
    logger.error('[ERROR] %s', msg);

    var headers = {};
    if (err.hasOwnProperty('headers')) {
        headers = err.headers;
    }

    var status = 500;
    if (err.hasOwnProperty('status')) {
        status = parseInt(err.status, 10);
    }
    return res.json({'error': err.message}, headers, status);
});

var environments = config[process.env.NODE_ENV];

for (var env in environments) {
    if (environments.hasOwnProperty(env) && env !== 'mongo') {
        app.set(env, environments[env]);
    }
}

// Set the user to be the SSO ID in the request
app.use(function (req, res, next) {
    if (/embed\/([a-z0-9]+)\.js/.test(req.url)) {
        return next();
    }
    var user;
    if (ENV.NODE_ENV === 'local') {
        user = {    //222003106//502090508
            'id': '502404807',
            'first_name': 'Biraja',
            'last_name': 'Maharana'
        };

        req.user = user;
        return next();
    }

    var ssoid = req.header('SM_USER', null);
    if (!ssoid) {
        var err = new Error('SM_USER header not found in request');
        err.status = 401;
        return next(err);
    }

    //Escape single quotes and double quotes of out names
    var givenname = req.header('givenname', null);
    if (givenname) {
        givenname = givenname.replace(/'/g, '&#039;').replace(/"/g, ' &quot;');
    }
    var sn = req.header('sn', null);
    if (sn) {
        sn = sn.replace(/'/g, '&#039;').replace(/"/g, ' &quot;');
    }

    user = {
        'id': ssoid,
        'first_name': req.header('givenname', null),
        'last_name': req.header('sn', null)
    };
    req.user = user;
    return next();
});

// Look up the dashboard and populate the model into the request
app.param('dashboard_id', function (req, res, next, id) {
    POSTGRESQL.getDashboardById(req,id)
        .then(function(dashboard){
            // console.log(dashboard);
            if (!dashboard) {
                var err = new Error('This mashup does not exist, or you do not have the rights to view this mashup');
                err.status = 404;
                routes.error(req, res, next, err);
            }
            if (dashboard.locked) {
                var standalone = /static/.test(req._parsedUrl.path);
                //if (POSTGRESQL.dashboardCanView1(dashboard.owner,req.user.id,dashboard.viewers,'') || standalone) {
                if (POSTGRESQL.dashboardCanView(dashboard.access) || standalone) {
                    req.dashboard = dashboard;
                    return next();
                } else {
                    var err = new Error('This mashup does not exist, or you do not have the rights to view this mashup');
                    err.status = 404;
                    return routes.error(req, res, next, err.message);
                }
            }else {
                req.dashboard = dashboard;
                return next();
            }
        },function (err) {
            routes.error(req, res, next, err);
        });


});

// Look up the widget and populate the model into the request
app.param('widget_id', function (req, res, next, id) {
    if (req.body.isNew) {
        req.widget = req.body;
        return next();
    }
    var body = req.body;
    POSTGRESQL.getWidgetById(req, id)
        .then(function (widget) {
            if (body && body.parameters) {
                if (!_.isObject(body.connector)) {
                    POSTGRESQL.getConnectorById(req, body.connector)
                        .then(function (conn) {
                            body.connector = conn;
                            req.widget = widget.set(body);
                            return next();
                        }, function (err) {
                            logger.error('Connector look up error ' + err);
                            delete body.connector;
                            req.widget = widget.set(body);
                            return next();
                        });
                } else {
                    req.widget = widget.set(body);
                    return next();
                }
            } else {
                if (/embed/.test(req.url)) {
                    req.widget = widget;
                    return next();
                }
                else if (!widget) {
                    var err = new Error('This widget does not exist, or your do not have the rights to view this widget.');
                    err.status = 404;
                    return routes.error(req, res, next, err.message);
                } else {
                    req.widget = widget;
                    return next();
                }
            }
        }, function (err) {
            err = new Error('This widget does not exist, or your do not have the rights to view this widget.');
            err.status = 404;
            return routes.error(req, res, next, err.message);
        });
});

// Routes
app.get('/', routes.home);
app.get('/error', routes.error);
// Proxy route for local testing
app.all('/proxy/*', routes.proxy);

//Will be absolute in upcoming releases
app.get('/dashboards/viewallrecords', routes.viewAllRecords);

app.get('/dashboard/create/:layout', routes.createDashboard);
app.get('/dashboard/:dashboard_id([a-z0-9]+)', routes.getDashboard);
//Will be absolute in upcoming releases
app.get('/dashboards/:dashboard_id([a-z0-9]+)', routes.getDashboard);

//Will be absolute in upcoming releases
app.get('/widgets/:widget_id([a-z0-9]+)', routes.widget);

app.get('/widget/create/:type', routes.createWidget);
app.get('/widget/:widget_id([a-z0-9]+)', routes.widget);

// API Routes
app.post('/api/v2/dashboard', dashboards.create);
app.get('/api/v2/dashboard/:dashboard_id([a-z0-9]+)', dashboards.get);
app.put('/api/v2/dashboard/:dashboard_id([a-z0-9]+)', dashboards.update);
app.delete('/api/v2/dashboard/:dashboard_id([a-z0-9]+)', dashboards.delete);
app.get('/api/v2/dashboard/:dashboard_id([a-z0-9]+)/widgets', widgets.list);

app.post('/api/v2/widget', widgets.create);
app.get('/api/v2/widget/:widget_id([a-z0-9]+)', widgets.get);
app.put('/api/v2/widget/:widget_id([a-z0-9]+)', widgets.update);
app.post('/api/v2/widget/:widget_id([a-z0-9]+)', widgets.create);
app.post('/api/v2/widget/:widget_id([a-z0-9]+)/data', widgets.getData);
app.post('/api/v2/widgets/data', widgets.getData);


app.delete('/api/v2/widget/:widget_id([a-z0-9]+)', widgets.delete);
app.get('/api/v2/widget/:widget_id([a-z0-9]+)/filters', widgets.getFiltersOperators);
app.post('/api/v2/widget/:widget_id([a-z0-9]+)/filters', widgets.getFiltersOperators); //New widgets
app.post('/api/v2/widget/:widget_id([a-z0-9]+)/copy/', widgets.copyWidget);

app.post('/api/v2/widget/changeowner/:id([a-z0-9]+)', widgets.updateOwnership);

/* This URL will listen for the static chart (standalone page) data */
app.get('/chart/static/:widget_id([a-z0-9]+)', routes.staticWidget);

app.get('/embed/:embed_id([a-z0-9]+).js', routes.embed);
app.get('/embed/widget/:widget_id([a-z0-9]+)', routes.embedWidget);

app.get('/dashboards/static/:dashboard_id([a-z0-9]+)', routes.getDashboard);

app.post('/api/v2/people/lookupservices/', dashboards.peopleSearch);
app.get('/api/v2/people/lookupservices', dashboards.peopleLookUp);

app.post('/api/v3/export/xlxs', routes.exportJsonToExcel);
app.get('/widgets/*', routes.createWidget);
app.all('*', function (req, res, next) {
    return routes.error(req, res, next, 'This page can not be found. Please check the URL and try again.');
});

module.exports = app;